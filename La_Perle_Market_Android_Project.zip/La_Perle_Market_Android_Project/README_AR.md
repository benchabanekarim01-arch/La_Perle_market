# La Perle Market — Android

هذا مشروع Android Studio حقيقي (WebView محلي) مبني على واجهة La Perle Market الحالية.

## البناء إلى APK
1. افتح المجلد في Android Studio.
2. انتظر مزامنة Gradle.
3. اختر `Build > Build APK(s)`.
4. ستجد APK في `app/build/outputs/apk/debug/app-debug.apk`.

النسخة الحالية هي v1 وتعمل محلياً. يمكن لاحقاً إضافة قارئ باركود بالكاميرا، قاعدة بيانات Room، الطباعة الحرارية، الموردين والمصاريف والنسخ الاحتياطي.
